var config = {
	type: Phaser.AUTO,
	width: 7930,
	height: 768,
physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: true
        }
    },
scene: {
		preload: preload,
		create: create,
		update: update
	}
};

var game = new Phaser.Game(config);	
var score = 0;
var platforms;
var player;
var cursors; 
var stars;
var scoreText;
var bomb;


function preload(){
	this.load.image('blue','assets/blue_invader.png');
	this.load.image('green','assets/green_invader.png');
	this.load.image('orange','assets/orange_invader.png');
	this.load.image('black','assets/black_invader.png');
	
	this.load.image('background','assets/back2.png')
	this.load.image('sol','assets/plat4.png');
	this.load.image('sol2','assets/plat5.png');
	this.load.image('mur','assets/plat6.png');
	this.load.spritesheet('perso','assets/perso2_run.png',{frameWidth: 29, frameHeight: 41});
	this.load.image('e1','assets/event.png');
	this.load.image('e2','assets/event.png');
	this.load.image('e3','assets/event.png');
	this.load.image('e4','assets/event.png');
	this.load.image('e5','assets/event.png');
	this.load.image('e6','assets/event.png');
	this.load.image('e7','assets/event.png');
	
	this.load.image('e8','assets/event.png');
	this.load.image('e9','assets/event.png');
	this.load.image('e10','assets/event.png');
	this.load.image('e11','assets/event.png');
	
	this.load.image('e12','assets/event.png');
	this.load.image('e13','assets/event.png');
	this.load.image('e14','assets/event.png');
	this.load.image('e15','assets/event.png');
	this.load.image('e16','assets/event.png');
}



function create(){
	var back = this.add.image(0,320,'background');

	platforms = this.physics.add.staticGroup();
	platforms.create(200,600,'sol');
	platforms.create(940,280,'sol2');
	platforms.create(580,500,'sol');
	platforms.create(320,360,'sol');
	
	platforms.create(1200,-20,'mur');
	platforms.create(1200,200,'mur');
	platforms.create(1300,300,'sol');
	platforms.create(1360,620,'sol2');
	platforms.create(1860,540,'sol2');
	platforms.create(1860,380,'sol');
	
	platforms.create(2340,220,'sol');
	platforms.create(2440,340,'sol');
	platforms.create(3130,140,'mur');
	platforms.create(3030,240,'sol');
	platforms.create(3240,540,'sol2');
	
	platforms.create(3420,-20,'mur');
	platforms.create(3420,200,'mur');
	platforms.create(3420,480,'mur');
	platforms.create(3520,580,'sol');
	platforms.create(3760,580,'sol');
	platforms.create(3720,300,'sol2');
	platforms.create(3916,440,'sol2');
	platforms.create(3860,540,'mur');
	platforms.create(3974,340,'mur');
	platforms.create(3960,580,'sol');
	platforms.create(4154,620,'sol');
	platforms.create(4324,620,'sol');
	platforms.create(4424,20,'mur');
	platforms.create(4424,240,'mur');
	platforms.create(4424,520,'mur');
	platforms.create(4480,620,'sol2');
	
	platforms.create(4660,580,'sol');
	platforms.create(5100,540,'mur');
	platforms.create(5100,280,'sol2');
	platforms.create(5440,340,'mur');
	platforms.create(5540,440,'sol');
	
	platforms.create(6000,380,'mur');
	platforms.create(6000,160,'mur');
	platforms.create(6056,480,'sol2');
	platforms.create(6180,620,'sol');
	platforms.create(6460,320,'sol');
	
	platforms.create(7130,400,'sol');
	platforms.create(7320,520,'sol');
	platforms.create(7510,640,'sol');
	platforms.create(7680,640,'sol');
	platforms.create(7850,640,'sol');
	
	
	
	
	e1 = this.physics.add.staticGroup();
	e1.create(940,240,'e1');
	e2 = this.physics.add.staticGroup();
	e2.create(1360,580,'e2');
	e3 = this.physics.add.staticGroup();
	e3.create(1860,500,'e3');
	e4 = this.physics.add.staticGroup();
	e4.create(2340,180,'e4');
	e5 = this.physics.add.staticGroup();
	e5.create(2440,300,'e5');
	e6 = this.physics.add.staticGroup();
	e6.create(3030,200,'e6');
	e7 = this.physics.add.staticGroup();
	e7.create(3240,500,'e7');
	e8 = this.physics.add.staticGroup();
	e8.create(3720,260,'e8');
	
	e9 = this.physics.add.staticGroup();
	e9.create(4480,580,'e9');
	e10 = this.physics.add.staticGroup();
	e10.create(5100,240,'e10');
	e11 = this.physics.add.staticGroup();
	e11.create(5540,400,'e11');
	
	e12 = this.physics.add.staticGroup();
	e12.create(6180,360,'e12');
	e13 = this.physics.add.staticGroup();
	e13.create(6260,310,'e13');
	e14 = this.physics.add.staticGroup();
	e14.create(6340,260,'e14');
	e15 = this.physics.add.staticGroup();
	e15.create(7130,360,'e15');
	e16 = this.physics.add.staticGroup();
	e16.create(7320,480,'e16');
	
	
	player = this.physics.add.sprite(200,540,'perso');
	player.setCollideWorldBounds(true);
	player.setBounce(0.2);
	player.body.setGravityY(000);
	this.physics.add.collider(player,platforms);
	
	

	cursors = this.input.keyboard.createCursorKeys(); 
	
	this.anims.create({
		key:'left',
		frames: this.anims.generateFrameNumbers('perso', {start: 0, end: 2}),
		frameRate: 20,
		repeat: -1
	});
	
	this.anims.create({
		key:'stop',
		frames: [{key: 'perso', frame:0}],
		frameRate: 20
	});
	
	stars = this.physics.add.group({
		key: 'none',
		repeat:0,
		setXY: {x:-100,y:0}
	});
	
	this.physics.add.collider(stars,platforms);
	this.physics.add.overlap(player,stars,collect1,null,this);
	this.physics.add.collider(e1,platforms);
	this.physics.add.overlap(player,e1,collect1,null,this);
	this.physics.add.overlap(player,e2,collect2,null,this);
	this.physics.add.overlap(player,e3,collect3,null,this);
	this.physics.add.overlap(player,e4,collect4,null,this);
	this.physics.add.overlap(player,e5,collect5,null,this);
	this.physics.add.overlap(player,e6,collect6,null,this);
	this.physics.add.overlap(player,e7,collect7,null,this);
	this.physics.add.overlap(player,e8,collect8,null,this);
	this.physics.add.overlap(player,e9,collect9,null,this);
	this.physics.add.overlap(player,e10,collect10,null,this);
	this.physics.add.overlap(player,e11,collect11,null,this);
	this.physics.add.overlap(player,e12,collect12,null,this);
	this.physics.add.overlap(player,e13,collect13,null,this);
	this.physics.add.overlap(player,e14,collect14,null,this);
	this.physics.add.overlap(player,e15,collect15,null,this);
	this.physics.add.overlap(player,e16,collect16,null,this);
	
	
	invaders = this.physics.add.group();
	this.physics.add.collider(invaders,platforms);
	this.physics.add.collider(player,invaders, hitblue, null, this);
	this.physics.add.collider(player,invaders, hitgreen, null, this);
	this.physics.add.collider(player,invaders, hitblack, null, this);
	this.physics.add.collider(player,invaders, hitorange, null, this);
}



function update(){
	if(cursors.left.isDown){
		player.anims.play('left', true);
		player.setVelocityX(-400);
		player.setFlipX(true);
	}else if(cursors.right.isDown){
		player.setVelocityX(400);
		player.anims.play('left', true);
		player.setFlipX(false);
	}else{
		player.anims.play('stop', true);
		player.setVelocityX(0);
	}
	
	if(cursors.up.isDown && player.body.touching.down){
		player.setVelocityY(-330);
	} 
	
}

function hitblue(player, blue){
	this.physics.pause();
	player.setTint(0xff0000);
	player.anims.play('turn');
	gameOver=true;
}

function hitgreen(player, green){
	this.physics.pause();
	player.setTint(0xff0000);
	player.anims.play('turn');
	gameOver=true;
}

function hitorange(player, orange){
	this.physics.pause();
	player.setTint(0xff0000);
	player.anims.play('turn');
	gameOver=true;
}

function hitblack(player, black){
	this.physics.pause();
	player.setTint(0xff0000);
	player.anims.play('turn');
	gameOver=true;
}



function collect1(player, e1){
	e1.disableBody(true,true);
	Text = this.add.text(680,180, 'Creation du premier jeu video : "Tennis for Two" sur oscilloscope', {fontSize: '12px', fill:'#ff0000'});
}
function collect2(player, e2){
	e2.disableBody(true,true);
	Text = this.add.text(1220,520, 'Creation du deuxieme jeu video : "Space war" sur ordinateur', {fontSize: '12px', fill:'#ff0000'});
}
function collect3(player, e3){
	e3.disableBody(true,true);
	Text = this.add.text(1720,460, 'Invention de la premiere console de jeu video', {fontSize: '12px', fill:'#ff0000'});
}
function collect4(player, e4){
	e4.disableBody(true,true);
	Text = this.add.text(2220,140, 'Invention de la borne d arcade', {fontSize: '12px', fill:'#ff0000'});
}
function collect5(player, e5){
	e5.disableBody(true,true);
	Text = this.add.text(2300,260, 'Premiere console de jeu video en salon', {fontSize: '12px', fill:'#ff0000'});
}
function collect6(player, e6){
	e6.disableBody(true,true);
	Text = this.add.text(2800,140, 'Grand succes de la console mythique Atari', {fontSize: '12px', fill:'#ff0000'});
}
function collect7(player, e7){
	e7.disableBody(true,true);
	Text = this.add.text(3100,440, 'Democratisation des jeux arcades', {fontSize: '12px', fill:'#ff0000'});
	Text = this.add.text(3100,460, 'Succes des bornes arcades', {fontSize: '12px', fill:'#ff0000'});
	
	var x = (player.x < 3500) ? 
			Phaser.Math.Between(3500,4400):
			Phaser.Math.Between(0,3500);
		var blue = invaders.create(x, 100, 'blue');
		blue.setBounce(1);
		blue.setCollideWorldBounds(true);
		blue.setVelocity(Phaser.Math.Between(-200, 200), 20);
		
		var black = invaders.create(x, 100, 'black');
		black.setBounce(1);
		black.setCollideWorldBounds(true);
		black.setVelocity(Phaser.Math.Between(-200, 200), 20);
		
		var orange = invaders.create(x, 100, 'orange');
		orange.setBounce(1);
		orange.setCollideWorldBounds(true);
		orange.setVelocity(Phaser.Math.Between(-200, 200), 20);
		
		var green = invaders.create(x, 100, 'green');
		green.setBounce(1);
		green.setCollideWorldBounds(true);
		green.setVelocity(Phaser.Math.Between(-200, 200), 20);
}

function collect8(player, e8){
	e8.disableBody(true,true);
	Text = this.add.text(3380,200, 'Crash des jeux console', {fontSize: '12px', fill:'#ff0000'});
}

function collect9(player, e9){
	e9.disableBody(true,true);
	Text = this.add.text(4460,540, 'Premiere console portable : la Gameboy', {fontSize: '12px', fill:'#ff0000'});
}
function collect10(player, e10){
	e10.disableBody(true,true);
	Text = this.add.text(5000,200, 'Debut de la 3D dans les jeux', {fontSize: '12px', fill:'#ff0000'});
}
function collect11(player, e11){
	e11.disableBody(true,true);
	Text = this.add.text(5460,340, 'Succes et guerre des consoles de jeux', {fontSize: '12px', fill:'#ff0000'});
	Text = this.add.text(5460,360, 'Phenomene Pokemon', {fontSize: '12px', fill:'#ff0000'});
}
function collect12(player, e12){
	e12.disableBody(true,true);
	Text = this.add.text(6080,330, 'Annee d or des jeux videos', {fontSize: '12px', fill:'#ff0000'});
	
}
function collect13(player, e13){
	e13.disableBody(true,true);
	Text = this.add.text(6160,280, 'Democratisation du multijoueur', {fontSize: '12px', fill:'#ff0000'});
	
}
function collect14(player, e14){
	e14.disableBody(true,true);
	Text = this.add.text(6200,230, 'Succes des nouvelles interfaces de jeu : Wii/Guitar Hero', {fontSize: '12px', fill:'#ff0000'});
	Text = this.add.text(6200,210, 'Avenement des jeux a grand budget "Triple A"', {fontSize: '12px', fill:'#ff0000'});
}
function collect15(player, e15){
	e15.disableBody(true,true);
	Text = this.add.text(7060,320, 'Debut du Serious Game', {fontSize: '12px', fill:'#ff0000'});
	Text = this.add.text(7060,300, 'Debut de l Esport', {fontSize: '12px', fill:'#ff0000'});
	
}
function collect16(player, e16){
	e16.disableBody(true,true);
	Text = this.add.text(7260,440, 'Debut des jeux en VR', {fontSize: '12px', fill:'#ff0000'});
	
}